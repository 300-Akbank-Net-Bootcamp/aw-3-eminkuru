namespace Vb.Base.Schema;

public abstract class BaseRequest
{
    
}