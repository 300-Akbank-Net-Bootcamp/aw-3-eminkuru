namespace Vb.Base.Schema;

public abstract class BaseResponse
{
    
}