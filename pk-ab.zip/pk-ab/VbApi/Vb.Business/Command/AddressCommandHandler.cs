﻿using System.Threading;
using System.Threading.Tasks;
using Vb.Base.Response;
using Vb.Business.Cqrs;
using Vb.Data;
using Vb.Data.Entity;
using Vb.Schema;
using AutoMapper;
using MediatR;

namespace Vb.Business.Command
{
	public class AddressCommandHandler :
		IRequestHandler<CreateAddressCommand, ApiResponse<AddressResponse>>,
		IRequestHandler<UpdateAddressCommand, ApiResponse>,
		IRequestHandler<DeleteAddressCommand, ApiResponse>
	{
		private readonly VbDbContext dbContext;
		private readonly IMapper mapper;

		public AddressCommandHandler(VbDbContext dbContext, IMapper mapper)
		{
			this.dbContext = dbContext;
			this.mapper = mapper;
		}

		public async Task<ApiResponse<AddressResponse>> Handle(CreateAddressCommand request, CancellationToken cancellationToken)
		{
			var addressEntity = mapper.Map<AddressRequest, Address>(request.Model);

			

			dbContext.Addresses.Add(addressEntity);
			await dbContext.SaveChangesAsync(cancellationToken);

			var responseDto = mapper.Map<AddressResponse>(addressEntity);
			return new ApiResponse<AddressResponse>(responseDto);
		}

		public async Task<ApiResponse> Handle(UpdateAddressCommand request, CancellationToken cancellationToken)
		{
			var existingAddress = await dbContext.Addresses.FindAsync(request.AddressId);

			if (existingAddress == null)
			{
				// Handle not found scenario
				return new ApiResponse("Address not found");
			}

			var ID = existingAddress.Id;
			mapper.Map(request.Model, existingAddress);
			existingAddress.Id = ID;	
			// Perform any additional validation if needed

			await dbContext.SaveChangesAsync(cancellationToken);

			return new ApiResponse();
		}

		public async Task<ApiResponse> Handle(DeleteAddressCommand request, CancellationToken cancellationToken)
		{
			var addressToDelete = await dbContext.Addresses.FindAsync(request.AddressId);

			if (addressToDelete == null)
			{
				// Handle not found scenario
				return new ApiResponse("Address not found");
			}
			addressToDelete.IsActive = false;
			await dbContext.SaveChangesAsync(cancellationToken);

			return new ApiResponse();
		}
	}
}
