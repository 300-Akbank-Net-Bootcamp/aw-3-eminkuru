﻿using System.Threading;
using System.Threading.Tasks;
using Vb.Base.Response;
using Vb.Business.Cqrs;
using Vb.Data;
using Vb.Data.Entity;
using Vb.Schema;
using AutoMapper;
using MediatR;

namespace Vb.Business.Command
{
	public class AccountTransactionCommandHandler :
		IRequestHandler<CreateAccountTransactionCommand, ApiResponse<AccountTransactionResponse>>,
		IRequestHandler<UpdateAccountTransactionCommand, ApiResponse>,
		IRequestHandler<DeleteAccountTransactionCommand, ApiResponse>
	{
		private readonly VbDbContext dbContext;
		private readonly IMapper mapper;

		public AccountTransactionCommandHandler(VbDbContext dbContext, IMapper mapper)
		{
			this.dbContext = dbContext;
			this.mapper = mapper;
		}

		public async Task<ApiResponse<AccountTransactionResponse>> Handle(CreateAccountTransactionCommand request, CancellationToken cancellationToken)
		{
			var AccountTransactionEntity = mapper.Map<AccountTransactionRequest, AccountTransaction>(request.Model);



			dbContext.AccountTransactions.Add(AccountTransactionEntity);
			await dbContext.SaveChangesAsync(cancellationToken);

			var responseDto = mapper.Map<AccountTransactionResponse>(AccountTransactionEntity);
			return new ApiResponse<AccountTransactionResponse>(responseDto);
		}

		public async Task<ApiResponse> Handle(UpdateAccountTransactionCommand request, CancellationToken cancellationToken)
		{
			var existingAccountTransaction = await dbContext.AccountTransactions.FindAsync(request.Id);

			if (existingAccountTransaction == null)
			{
				// Handle not found scenario
				return new ApiResponse("AccountTransaction not found");
			}

			var ID = existingAccountTransaction.Id;
			mapper.Map(request.Model, existingAccountTransaction);
			existingAccountTransaction.Id = ID;
			// Perform any additional validation if needed

			await dbContext.SaveChangesAsync(cancellationToken);

			return new ApiResponse();
		}

		public async Task<ApiResponse> Handle(DeleteAccountTransactionCommand request, CancellationToken cancellationToken)
		{
			var AccountTransactionToDelete = await dbContext.AccountTransactions.FindAsync(request.Id);

			if (AccountTransactionToDelete == null)
			{
				// Handle not found scenario
				return new ApiResponse("AccountTransaction not found");
			}
			AccountTransactionToDelete.IsActive = false;
			await dbContext.SaveChangesAsync(cancellationToken);

			return new ApiResponse();
		}
	}
}
