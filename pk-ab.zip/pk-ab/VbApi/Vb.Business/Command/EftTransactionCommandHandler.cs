﻿using System.Threading;
using System.Threading.Tasks;
using Vb.Base.Response;
using Vb.Business.Cqrs;
using Vb.Data;
using Vb.Data.Entity;
using Vb.Schema;
using AutoMapper;
using MediatR;

namespace Vb.Business.Command
{
	public class EftTransactionCommandHandler :
		IRequestHandler<CreateEftTransactionCommand, ApiResponse<EftTransactionResponse>>,
		IRequestHandler<UpdateEftTransactionCommand, ApiResponse>,
		IRequestHandler<DeleteEftTransactionCommand, ApiResponse>
	{
		private readonly VbDbContext dbContext;
		private readonly IMapper mapper;

		public EftTransactionCommandHandler(VbDbContext dbContext, IMapper mapper)
		{
			this.dbContext = dbContext;
			this.mapper = mapper;
		}

		public async Task<ApiResponse<EftTransactionResponse>> Handle(CreateEftTransactionCommand request, CancellationToken cancellationToken)
		{
			var EftTransactionEntity = mapper.Map<EftTransactionRequest, EftTransaction>(request.Model);



			dbContext.EftTransactions.Add(EftTransactionEntity);
			await dbContext.SaveChangesAsync(cancellationToken);

			var responseDto = mapper.Map<EftTransactionResponse>(EftTransactionEntity);
			return new ApiResponse<EftTransactionResponse>(responseDto);
		}

		public async Task<ApiResponse> Handle(UpdateEftTransactionCommand request, CancellationToken cancellationToken)
		{
			var existingEftTransaction = await dbContext.EftTransactions.FindAsync(request.Id);

			if (existingEftTransaction == null)
			{
				// Handle not found scenario
				return new ApiResponse("EftTransaction not found");
			}

			var ID = existingEftTransaction.Id;
			mapper.Map(request.Model, existingEftTransaction);
			existingEftTransaction.Id = ID;
			// Perform any additional validation if needed

			await dbContext.SaveChangesAsync(cancellationToken);

			return new ApiResponse();
		}

		public async Task<ApiResponse> Handle(DeleteEftTransactionCommand request, CancellationToken cancellationToken)
		{
			var EftTransactionToDelete = await dbContext.EftTransactions.FindAsync(request.Id);

			if (EftTransactionToDelete == null)
			{
				// Handle not found scenario
				return new ApiResponse("EftTransaction not found");
			}
			EftTransactionToDelete.IsActive = false;
			await dbContext.SaveChangesAsync(cancellationToken);

			return new ApiResponse();
		}
	}
}
