﻿using System.Threading;
using System.Threading.Tasks;
using Vb.Base.Response;
using Vb.Business.Cqrs;
using Vb.Data;
using Vb.Data.Entity;
using Vb.Schema;
using AutoMapper;
using MediatR;

namespace Vb.Business.Command
{
	public class ContactCommandHandler :
		IRequestHandler<CreateContactCommand, ApiResponse<ContactResponse>>,
		IRequestHandler<UpdateContactCommand, ApiResponse>,
		IRequestHandler<DeleteContactCommand, ApiResponse>
	{
		private readonly VbDbContext dbContext;
		private readonly IMapper mapper;

		public ContactCommandHandler(VbDbContext dbContext, IMapper mapper)
		{
			this.dbContext = dbContext;
			this.mapper = mapper;
		}

		public async Task<ApiResponse<ContactResponse>> Handle(CreateContactCommand request, CancellationToken cancellationToken)
		{
			var ContactEntity = mapper.Map<ContactRequest, Contact>(request.Model);



			dbContext.Contacts.Add(ContactEntity);
			await dbContext.SaveChangesAsync(cancellationToken);

			var responseDto = mapper.Map<ContactResponse>(ContactEntity);
			return new ApiResponse<ContactResponse>(responseDto);
		}

		public async Task<ApiResponse> Handle(UpdateContactCommand request, CancellationToken cancellationToken)
		{
			var existingContact = await dbContext.Contacts.FindAsync(request.Id);

			if (existingContact == null)
			{
				// Handle not found scenario
				return new ApiResponse("Contact not found");
			}

			var ID = existingContact.Id;
			mapper.Map(request.Model, existingContact);
			existingContact.Id = ID;
			// Perform any additional validation if needed

			await dbContext.SaveChangesAsync(cancellationToken);

			return new ApiResponse();
		}

		public async Task<ApiResponse> Handle(DeleteContactCommand request, CancellationToken cancellationToken)
		{
			var ContactToDelete = await dbContext.Contacts.FindAsync(request.Id);

			if (ContactToDelete == null)
			{
				// Handle not found scenario
				return new ApiResponse("Contact not found");
			}
			ContactToDelete.IsActive = false;
			await dbContext.SaveChangesAsync(cancellationToken);

			return new ApiResponse();
		}
	}
}
