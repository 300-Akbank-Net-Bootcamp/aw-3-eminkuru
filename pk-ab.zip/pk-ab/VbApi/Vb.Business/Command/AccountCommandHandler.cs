﻿using System.Threading;
using System.Threading.Tasks;
using Vb.Base.Response;
using Vb.Business.Cqrs;
using Vb.Data;
using Vb.Data.Entity;
using Vb.Schema;
using AutoMapper;
using MediatR;

namespace Vb.Business.Command
{
	public class AccountCommandHandler :
		IRequestHandler<CreateAccountCommand, ApiResponse<AccountResponse>>,
		IRequestHandler<UpdateAccountCommand, ApiResponse>,
		IRequestHandler<DeleteAccountCommand, ApiResponse>
	{
		private readonly VbDbContext dbContext;
		private readonly IMapper mapper;

		public AccountCommandHandler(VbDbContext dbContext, IMapper mapper)
		{
			this.dbContext = dbContext;
			this.mapper = mapper;
		}

		public async Task<ApiResponse<AccountResponse>> Handle(CreateAccountCommand request, CancellationToken cancellationToken)
		{
			var AccountEntity = mapper.Map<AccountRequest, Account>(request.Model);



			dbContext.Accounts.Add(AccountEntity);
			await dbContext.SaveChangesAsync(cancellationToken);

			var responseDto = mapper.Map<AccountResponse>(AccountEntity);
			return new ApiResponse<AccountResponse>(responseDto);
		}

		public async Task<ApiResponse> Handle(UpdateAccountCommand request, CancellationToken cancellationToken)
		{
			var existingAccount = await dbContext.Accounts.FindAsync(request.Id);

			if (existingAccount == null)
			{
				// Handle not found scenario
				return new ApiResponse("Account not found");
			}

			var ID = existingAccount.AccountNumber;
			mapper.Map(request.Model, existingAccount);
			existingAccount.AccountNumber = ID;
			// Perform any additional validation if needed

			await dbContext.SaveChangesAsync(cancellationToken);

			return new ApiResponse();
		}

		public async Task<ApiResponse> Handle(DeleteAccountCommand request, CancellationToken cancellationToken)
		{
			var AccountToDelete = await dbContext.Accounts.FindAsync(request.Id);

			if (AccountToDelete == null)
			{
				// Handle not found scenario
				return new ApiResponse("Account not found");
			}
			AccountToDelete.IsActive = false;
			await dbContext.SaveChangesAsync(cancellationToken);

			return new ApiResponse();
		}
	}
}
