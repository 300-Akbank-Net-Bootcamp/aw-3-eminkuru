﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using MediatR;
using Vb.Base.Response;
using Vb.Business.Cqrs;
using Vb.Data.Entity;
using Vb.Data;
using Vb.Schema;
using Microsoft.EntityFrameworkCore;

namespace Vb.Business.Query;




public class EftTransactionQueryHandler :
	IRequestHandler<GetAllEftTransactionsQuery, ApiResponse<List<EftTransactionResponse>>>,
	IRequestHandler<GetEftTransactionsByIdQuery, ApiResponse<EftTransactionResponse>>
{
	private readonly VbDbContext dbContext;
	private readonly IMapper mapper;

	public EftTransactionQueryHandler(VbDbContext dbContext, IMapper mapper)
	{
		this.dbContext = dbContext;
		this.mapper = mapper;
	}

	public async Task<ApiResponse<List<EftTransactionResponse>>> Handle(GetAllEftTransactionsQuery request,
		CancellationToken cancellationToken)
	{
		var list = await dbContext.Set<EftTransaction>()
			.Include(x => x.Account).ToListAsync(cancellationToken);

		var mappedList = mapper.Map<List<EftTransaction>, List<EftTransactionResponse>>(list);
		return new ApiResponse<List<EftTransactionResponse>>(mappedList);
	}

	public async Task<ApiResponse<EftTransactionResponse>> Handle(GetEftTransactionsByIdQuery request,
		CancellationToken cancellationToken)
	{
		var entity = await dbContext.Set<EftTransaction>()
			.Include(x => x.Account)
			.FirstOrDefaultAsync(x => x.Id == request.Id, cancellationToken);

		if (entity == null)
		{
			return new ApiResponse<EftTransactionResponse>("Record not found");
		}

		var mapped = mapper.Map<EftTransaction, EftTransactionResponse>(entity);
		return new ApiResponse<EftTransactionResponse>(mapped);
	}
}
