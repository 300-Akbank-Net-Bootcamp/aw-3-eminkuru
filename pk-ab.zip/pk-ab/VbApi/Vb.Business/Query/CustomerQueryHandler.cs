using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Vb.Base.Response;
using Vb.Business.Cqrs;
using Vb.Data;
using Vb.Data.Entity;
using Vb.Schema;

namespace Vb.Business.Query;

public class CustomerQueryHandler :
    IRequestHandler<GetAllCustomerQuery, ApiResponse<List<AdressResponse>>>,
    IRequestHandler<GetCustomerByIdQuery, ApiResponse<AdressResponse>>,
    IRequestHandler<GetCustomerByParameterQuery, ApiResponse<List<AdressResponse>>>
{
    private readonly VbDbContext dbContext;
    private readonly IMapper mapper;

    public CustomerQueryHandler(VbDbContext dbContext, IMapper mapper)
    {
        this.dbContext = dbContext;
        this.mapper = mapper;
    }

    public async Task<ApiResponse<List<AdressResponse>>> Handle(GetAllCustomerQuery request,
        CancellationToken cancellationToken)
    {
        var list = await dbContext.Set<Customer>()
            .Include(x => x.Accounts)
            .Include(x => x.Contacts)
            .Include(x => x.Addresses).ToListAsync(cancellationToken);
        
        var mappedList = mapper.Map<List<Customer>, List<AdressResponse>>(list);
         return new ApiResponse<List<AdressResponse>>(mappedList);
    }

    public async Task<ApiResponse<AdressResponse>> Handle(GetCustomerByIdQuery request,
        CancellationToken cancellationToken)
    {
        var entity =  await dbContext.Set<Customer>()
            .Include(x => x.Accounts)
            .Include(x => x.Contacts)
            .Include(x => x.Addresses)
            .FirstOrDefaultAsync(x => x.CustomerNumber == request.Id, cancellationToken);

        if (entity == null)
        {
            return new ApiResponse<AdressResponse>("Record not found");
        }
        
        var mapped = mapper.Map<Customer, AdressResponse>(entity);
        return new ApiResponse<AdressResponse>(mapped);
    }

    public async Task<ApiResponse<List<AdressResponse>>> Handle(GetCustomerByParameterQuery request,
        CancellationToken cancellationToken)
    {
        var list =  await dbContext.Set<Customer>()
            .Include(x => x.Accounts)
            .Include(x => x.Contacts)
            .Include(x => x.Addresses)
            .Where(x =>
            x.FirstName.ToUpper().Contains(request.FirstName.ToUpper()) ||
            x.LastName.ToUpper().Contains(request.LastName.ToUpper()) ||
            x.IdentityNumber.ToUpper().Contains(request.IdentiyNumber.ToUpper())
        ).ToListAsync(cancellationToken);
        
        var mappedList = mapper.Map<List<Customer>, List<AdressResponse>>(list);
        return new ApiResponse<List<AdressResponse>>(mappedList);
    }
}