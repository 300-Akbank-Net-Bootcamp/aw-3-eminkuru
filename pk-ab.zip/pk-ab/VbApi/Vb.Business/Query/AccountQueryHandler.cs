﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using MediatR;
using Vb.Base.Response;
using Vb.Business.Cqrs;
using Vb.Data.Entity;
using Vb.Data;
using Vb.Schema;
using Microsoft.EntityFrameworkCore;

namespace Vb.Business.Query;


	public class AccountQueryHandler :
	IRequestHandler<GetAllAccountsQuery, ApiResponse<List<AccountResponse>>>,
	IRequestHandler<GetAccountsByIdQuery, ApiResponse<AccountResponse>>
{
	private readonly VbDbContext dbContext;
	private readonly IMapper mapper;

	public AccountQueryHandler(VbDbContext dbContext, IMapper mapper)
	{
		this.dbContext = dbContext;
		this.mapper = mapper;
	}

	public async Task<ApiResponse<List<AccountResponse>>> Handle(GetAllAccountsQuery request,
		CancellationToken cancellationToken)
	{
		var list = await dbContext.Set<Account>()
			.Include(x => x.Customer).ToListAsync(cancellationToken);

		var mappedList = mapper.Map<List<Account>, List<AccountResponse>>(list);
		return new ApiResponse<List<AccountResponse>>(mappedList);
	}

	public async Task<ApiResponse<AccountResponse>> Handle(GetAccountsByIdQuery request,
		CancellationToken cancellationToken)
	{
		var entity = await dbContext.Set<Account>()
			.Include(x => x.Customer)
			.FirstOrDefaultAsync(x => x.AccountNumber == request.Id, cancellationToken);

		if (entity == null)
		{
			return new ApiResponse<AccountResponse>("Record not found");
		}

		var mapped = mapper.Map<Account, AccountResponse>(entity);
		return new ApiResponse<AccountResponse>(mapped);
	}
}
